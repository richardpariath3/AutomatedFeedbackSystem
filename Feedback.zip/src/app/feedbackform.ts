export interface IFeedbackform 
{

    course_id:any;
    title:any;
    form_id:any;
    comments:any;
    date:any;
    trainer_energy:any;
    trainer_interactivity:any;
    trainer_communication:any;
    trainer_delivery:any;
    trainer_knowledge:any;
    duration:any;
    exercises:any;
    examples:any;
    appropriateness:any;
    understandable:any;
    training_effectiveness:any;
    training_objective:any;
    training_program:any;
    random_number:any;
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Router } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { routes} from './app.route.module';
import { CourseFilterPipe} from './course-filter.pipe'
import { CourseinFilterPipe} from './course-in-filter.pipe'
import {DataTableModule} from 'angular2-datatable';
import {NgxPaginationModule} from 'ngx-pagination';
import {AmChartsModule} from '@amcharts/amcharts3-angular';
import { TrainingfeedbackComponent } from './trainingfeedback/trainingfeedback.component';
import { ConsolidatedtrainingfeedbackComponent } from './consolidatedtrainingfeedback/consolidatedtrainingfeedback.component';
import { TrainerfeedbackComponent } from './trainerfeedback/trainerfeedback.component';
import { ConsolidatedtrainerfeedbackComponent } from './consolidatedtrainerfeedback/consolidatedtrainerfeedback.component';
import {SuiModule} from 'ng2-semantic-ui';
import {AccordionModule,AccordionGroup,AccordionHeading} from 'ngx-accordion';
import {NgSemanticModule} from 'ng-semantic';
import {HttpModule,Response,RequestMethod,RequestOptions,Headers} from '@angular/http';
import { KeysPipe} from './keys.pipe'
import {AutoCompleteModule} from 'primeng/primeng';
import {Ng2AutoCompleteModule} from 'ng2-auto-complete';
import { OverallconsolidatedtrainerfeedbackComponent } from './overallconsolidatedtrainerfeedback/overallconsolidatedtrainerfeedback.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavbarComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    FeedbackComponent,
    CourseFilterPipe,
    CourseinFilterPipe,
    TrainingfeedbackComponent,
    ConsolidatedtrainingfeedbackComponent,
    TrainerfeedbackComponent,
    ConsolidatedtrainerfeedbackComponent,
    OverallconsolidatedtrainerfeedbackComponent,
    KeysPipe,
   
   

  ],
  imports: [
    BrowserModule,Ng2AutoCompleteModule,routes,  AutoCompleteModule,FormsModule, ReactiveFormsModule, DataTableModule, NgxPaginationModule,AmChartsModule,SuiModule,AccordionModule,HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

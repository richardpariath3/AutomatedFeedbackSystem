import {PipeTransform,Pipe} from '@angular/core';
import {ITest} from './test'
import {IFeedbackform} from './feedbackform'
@Pipe({
    name:'courseinFilter'
})
export class CourseinFilterPipe implements PipeTransform
{
    transform(value:any[],filterBy: any): any
    {
        filterBy=filterBy?filterBy.toUpperCase():null;
        return filterBy ? value.filter((course:ITest)=>course.instructor.toUpperCase().indexOf(filterBy)!==-1):value;
    }


    
}



import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

   technologyUsed: string = 'Made using ANGULARJS 2, AMCHART and SPRINGBOOT';
   companyName: string = '@Solverminds';
   purposeOfProject: string = 'as Internship Project';
  constructor() { }

  ngOnInit() {
  }

}

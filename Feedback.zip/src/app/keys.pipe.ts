import {PipeTransform,Pipe} from '@angular/core';
import {ICourse} from './course'
import {IFeedbackform} from './feedbackform'
@Pipe({
    name:'keys'
})
export class KeysPipe implements PipeTransform
{
   transform(value, args:string[]) : any {
    if (!value) {
      return value;
    } 

    let keys = [];
    for (let key in value) {
      keys.push({key: key, value: value[key]});
    }
    return keys;
  }

    
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overallconsolidatedtrainerfeedback',
  templateUrl: './overallconsolidatedtrainerfeedback.component.html',
  styleUrls: ['./overallconsolidatedtrainerfeedback.component.css']
})
export class OverallconsolidatedtrainerfeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import {Injectable} from '@angular/core'
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {ITest} from '../test';

@Injectable()
export class TestService {

    private course_details='';
    constructor(private _http:Http){}
    getCourse(): any[]
    {
        return [ 
        {cid:1,title:"asd",description:"asda",instructor_type:"123",instructor:"pooooi",duration:"40",total_cost:"5000",permanent_cost:"23123",no_of_participants:"21",location:"1",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"07/06/17",to_date:"07/06/17",courseid:"2",training_training_log_id:"1"},
        {cid:2,title:"qw",description:"zxc",instructor_type:"1",instructor:"tuy",duration:"40",total_cost:"15000",permanent_cost:"23123",no_of_participants:"21",location:"2",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"09/06/17",to_date:"07/08/17",courseid:"2",training_training_log_id:"2"},
        {cid:3,title:"we",description:"axcv",instructor_type:"2",instructor:"rty",duration:"40",total_cost:"20000",permanent_cost:"23123",no_of_participants:"212",location:"2",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"10/06/17",to_date:"07/12/17",courseid:"2",training_training_log_id:"3"},
        {cid:4,title:"rt",description:"cvb",instructor_type:"1",instructor:"trwe",duration:"40",total_cost:"8000",permanent_cost:"23123",no_of_participants:"431",location:"1",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"11/06/17",to_date:"07/03/18",courseid:"2",training_training_log_id:"4"},
        {cid:5,title:"ty",description:"vbn",instructor_type:"3",instructor:"ghj",duration:"40",total_cost:"13000",permanent_cost:"23123",no_of_participants:"27",location:"1",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"12/06/17",to_date:"07/08/17",courseid:"2",training_training_log_id:"5"},
        {cid:6,title:"yu",description:"vnb",instructor_type:"4",instructor:"dfgs",duration:"40",total_cost:"5000",permanent_cost:"23123",no_of_participants:"400",location:"2",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"15/06/17",to_date:"07/08/17",courseid:"2",training_training_log_id:"6"},
        {cid:7,title:"ui",description:"ads",instructor_type:"5",instructor:"hfdg",duration:"40",total_cost:"9000",permanent_cost:"23123",no_of_participants:"30",location:"2",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"20/06/17",to_date:"07/02/18",courseid:"2",training_training_log_id:"7"},
        {cid:8,title:"aio",description:"sdf",instructor_type:"6",instructor:"saf",duration:"40",total_cost:"2000",permanent_cost:"23123",no_of_participants:"2",location:"1",create_date:"05/05/17",created_by:"UIOP",status:"2",from_date:"21/06/17",to_date:"07/06/17",courseid:"2",training_training_log_id:"8"},
        ];
    }

    private handleError(error:Response)
    {
        console.error(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}
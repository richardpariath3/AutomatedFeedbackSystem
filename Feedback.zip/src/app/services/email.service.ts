import {Injectable} from '@angular/core'
import {Http,Response,RequestOptions,Headers,URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {ICourse} from '../course';

@Injectable()
export class EmailService {

    

    constructor(private _http:Http){}

    sendEMAIL(value:any): any{
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
    let myParams = new URLSearchParams();
    myParams.append('cid',value);
    let body = myParams.toString();
    let options = new RequestOptions({ headers: headers });
    return this._http.post('http://192.168.22.23:7000/mail?cid='+value, options ).map((res: Response) => res.json());
  }

    private handleError(error:Response)
    {
        console.error(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}
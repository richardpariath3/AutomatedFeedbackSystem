import {PipeTransform,Pipe} from '@angular/core';
import {ICourse} from './course'
import {IFeedbackform} from './feedbackform'
@Pipe({
    name:'courseFilter'
})
export class CourseFilterPipe implements PipeTransform
{
    transform(value:any[],filterBy: any,filterinBy:any): any
    {
        filterBy=filterBy?filterBy.toUpperCase():null;
        return filterBy ? value.filter((course:IFeedbackform)=>course.title.toUpperCase().indexOf(filterBy)!==-1):value;
    }


    
}
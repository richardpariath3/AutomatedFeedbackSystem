import { Component, OnInit } from '@angular/core';
import {FeedbackformService} from '../services/feedbackform.service';
import {CourseService} from '../services/course.service';
import {Ng2AutoCompleteModule} from 'ng2-auto-complete';
import {Router} from '@angular/router';
import {FormsModule ,FormGroup,FormBuilder} from '@angular/forms'
import {IFeedbackform} from '../feedbackform'
import {ICourse} from '../course';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { CourseinFilterPipe} from '../course-in-filter.pipe'
import { KeysPipe} from '../keys.pipe'
import { Observable } from 'rxjs/Observable';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import 'rxjs/add/observable/of';

@Component({
  selector: 'app-trainerfeedback',
  templateUrl: './trainerfeedback.component.html',
  styleUrls: ['./trainerfeedback.component.css'],
   providers:[FeedbackformService,CourseService]
})
export class TrainerfeedbackComponent implements OnInit {
  errorMessage:string;
   feed:IFeedbackform[];
   courses:ICourse[];
   listFilter: string = '';
   listinFilter: string = '';
   getData:string;
   public myForm: FormGroup;
  constructor(private _sanitizer: DomSanitizer,private builder: FormBuilder,private feedbackService: FeedbackformService,private courseService: CourseService) { }

  ngOnInit():void {
    this.myForm=this.builder.group({
      feeds:"",
    })
    this.courseService.getCourse().subscribe((feed:ICourse[])=>this.courses=feed, error=>this.errorMessage=<any>error);
   // this.courses=this.testService.getCourse();
   
}

autocompleListFormatter = (data: any) => {
    let html = `<span style='color:grey'>Title: ${data.title} | Instructor: ${data.instructor} | From: ${data.from_date} </span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }

onSubmit(obj:any):void{
this.feedbackService.getFeedbackform(obj).subscribe((feed:IFeedbackform[])=>this.feed=feed, error=>this.errorMessage=<any>error);
}


}






  

   
    

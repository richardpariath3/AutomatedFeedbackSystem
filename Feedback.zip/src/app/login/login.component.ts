import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule, AbstractControl,FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-loginpage',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
myForm: FormGroup;
sku: AbstractControl;
pass: AbstractControl;
constructor(private router: Router,fb: FormBuilder)
  {
    this.myForm=fb.group({
      'sku':['',Validators.required],
      'pass':['',Validators.required]
      
    });
    this.sku=this.myForm.controls['sku'];
    this.pass=this.myForm.controls['pass'];
  }

  ngOnInit() {
  }

  onSubmit(value: any): void
   {
     
    if(!this.myForm.dirty)
    {
      alert("Invalid username or password");
      
    }
    else if (this.myForm.invalid)
      {
        
         alert("Invalid username or password");
   }
   else{
      this.router.navigateByUrl("/admin/dashboard/trainingfeedback");
   }
   }
}

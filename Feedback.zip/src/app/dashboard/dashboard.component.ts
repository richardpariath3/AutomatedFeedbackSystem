import { Component, OnInit } from '@angular/core';
import {RouterLink,RouterLinkActive} from '@angular/router';
import {AmChartsService} from '@amcharts/amcharts3-angular';
import {AmChartsModule} from '@amcharts/amcharts3-angular';
import {NgxPaginationModule} from 'ngx-pagination';
@Component({
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  
})
export class DashboardComponent implements OnInit {

  constructor(private AmCharts:AmChartsService) {
       }

  ngOnInit() {

  }


}

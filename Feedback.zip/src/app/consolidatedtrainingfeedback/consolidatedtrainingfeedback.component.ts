import { Component, OnInit } from '@angular/core';
import {AmChartsService,AmChartsDirective} from "@amcharts/amcharts3-angular";
import {SuiCheckboxModule,SuiRatingModule} from 'ng2-semantic-ui';
import {IFeedbackform} from '../feedbackform'
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import {NgxPaginationModule} from 'ngx-pagination';
import {CourseinFilterPipe} from '../course-in-filter.pipe';
import {FeedbackformService} from '../services/feedbackform.service';
import {AccordionModule,AccordionGroup,AccordionHeading} from 'ngx-accordion';
import {MenuItem} from 'primeng/primeng';
import { Observable } from 'rxjs/Observable';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import 'rxjs/add/observable/of';
import {TestService} from '../services/test.service';
import {ITest} from '../test';
import {FormsModule ,FormGroup,FormBuilder} from '@angular/forms'
import {ICourse} from '../course'
import {CourseService} from '../services/course.service';

@Component({
  selector: 'app-consolidatedtrainingfeedback',
  templateUrl: './consolidatedtrainingfeedback.component.html',
  styleUrls: ['./consolidatedtrainingfeedback.component.css'],
  providers:[FeedbackformService,CourseService]
})
export class ConsolidatedtrainingfeedbackComponent implements OnInit {
private chart:any;
private indextab:number=-1;
listFilter: string = '';
feed:IFeedbackform[];
errorMessage:string;
courses:ICourse[];
listinFilter: string = '';
getData:string;
public myForm: FormGroup;
constructor(private _sanitizer: DomSanitizer,private builder: FormBuilder,private courseService: CourseService,private AmCharts:AmChartsService,private feedbackService: FeedbackformService) { }

onSubmit(obj:number):void
{
 this.feedbackService.getFeedbackform(obj).subscribe((feed:IFeedbackform[])=>this.feed=feed, error=>this.errorMessage=<any>error);
let countofcharts:number=8;
let jsonValue:any;
let i:number=1;
jsonValue={ "1": [{"category": "Excellent","column-1": 45},{"category": "Good","column-1": 50,},{"category": "Average","column-1": 21,},{"category": "Poor","column-1": 10,}],
  "2": [{"category": "Yes","column-1": 75},{"category": "No","column-1": 50,},{"category": "Somewhat","column-1": 21,},{"category": "Poor","column-1": 10,}],
  "3": [{"category": "Yes","column-1": 75},{"category": "No","column-1": 50,},{"category": "Somewhat","column-1": 21,}],
  "4": [{"category": "Definitely","column-1": 45},{"category": "Somewhat","column-1": 50,},{"category": "No","column-1": 21,}],
  "5": [{"category": "Too Long","column-1": 85},{"category": "Adequate","column-1": 55,},{"category": "Insufficient","column-1": 21,}],
  "6": [{"category": "Excellent","column-1": 89},{"category": "Adequate","column-1": 10,},{"category": "Not Adequate","column-1": 61,},{"category": "Not Applicable","column-1": 0,}],
  "7": [{"category": "Excellent","column-1": 55},{"category": "Adequate","column-1": 10,},{"category": "Not Adequate","column-1": 11,},{"category": "Not Applicable","column-1": 0,}],
  "8": [{"category": "Excellent","column-1": 3},{"category": "Adequate","column-1": 90,},{"category": "Not Adequate","column-1": 21,},{"category": "Not Applicable","column-1": 0,}],
 
}

for(i=1;i<countofcharts;i++){
  this.chart=this.AmCharts.makeChart("chartdiv"+i,
    {
  "type": "pie",
  "theme": "none",
  "dataProvider": jsonValue[i],
  "titleField": "category",
  "valueField": "column-1",
  "labelRadius": 5,
  "radius": "20%",
  "legend":[
{
  "position":"right",
  "marginRight":100,
  "autoMargins":false
}
  ],
  "innerRadius": "60%",
  "labelText": "[[title]]-[[value]]"
    } 

    );
}


   
}


  ngOnInit() {
       this.myForm=this.builder.group({
      feeds:"",
    })
    this.courseService.getCourse().subscribe((feed:ICourse[])=>this.courses=feed, error=>this.errorMessage=<any>error);
    //this.courses=this.testService.getCourse();
     
  }

    onTabOpen(event):void{
      this.indextab=event.index;
    }

  autocompleListFormatter = (data: any) => {
    let html = `<span style='color:grey'>Title: ${data.title} | Instructor: ${data.instructor} | From: ${data.from_date} </span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }
 
}


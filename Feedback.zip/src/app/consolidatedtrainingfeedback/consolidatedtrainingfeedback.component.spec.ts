import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatedtrainingfeedbackComponent } from './consolidatedtrainingfeedback.component';

describe('ConsolidatedtrainingfeedbackComponent', () => {
  let component: ConsolidatedtrainingfeedbackComponent;
  let fixture: ComponentFixture<ConsolidatedtrainingfeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsolidatedtrainingfeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidatedtrainingfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

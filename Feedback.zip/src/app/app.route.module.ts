import { NgModule }              from '@angular/core';
import { RouterModule, Routes, Router }  from '@angular/router';
import {HomeComponent} from './home/home.component';
import {HeaderComponent} from './header/header.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {FeedbackComponent} from './feedback/feedback.component';
import {AppComponent} from './app.component';
import {ModuleWithProviders} from '@angular/core';
import {LoginComponent} from './login/login.component';
import { TrainingfeedbackComponent } from './trainingfeedback/trainingfeedback.component';
import { ConsolidatedtrainingfeedbackComponent } from './consolidatedtrainingfeedback/consolidatedtrainingfeedback.component';
import { TrainerfeedbackComponent } from './trainerfeedback/trainerfeedback.component';
import { ConsolidatedtrainerfeedbackComponent } from './consolidatedtrainerfeedback/consolidatedtrainerfeedback.component';
import { OverallconsolidatedtrainerfeedbackComponent } from './overallconsolidatedtrainerfeedback/overallconsolidatedtrainerfeedback.component';


export const appRoutes: Routes = [
  { path: '', component: LoginComponent},
  { path: 'login', component: LoginComponent},
  { path: 'admin', component: HomeComponent,
      children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent,
        children: [
          {path:'trainingfeedback', component: TrainingfeedbackComponent },
          {path:'consolidatedtrainingfeedback', component:ConsolidatedtrainingfeedbackComponent},
          {path:'trainerfeedback', component:TrainerfeedbackComponent },
          {path:'consolidatedtrainerfeedback', component:ConsolidatedtrainerfeedbackComponent},
          {path:'overallconsolidatedtrainerfeedback', component:OverallconsolidatedtrainerfeedbackComponent}

        ]
      },
      { path: 'display/courses', component: FeedbackComponent },
      
    ]
  }
  
];
 
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {
}

export const routes: ModuleWithProviders =RouterModule.forRoot(appRoutes)


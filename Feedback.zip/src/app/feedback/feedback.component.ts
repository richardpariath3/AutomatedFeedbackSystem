import { Component, OnInit } from '@angular/core';
import {CourseService} from '../services/course.service';
import {Router} from '@angular/router';
import {FormsModule } from '@angular/forms'
import {ICourse} from '../course'
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { CourseFilterPipe} from '../course-filter.pipe'
import { CourseinFilterPipe} from '../course-in-filter.pipe'
import {NgxPaginationModule} from 'ngx-pagination';
import {EmailService} from '../services/email.service';


@Component({
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css'],
  providers:[CourseService,EmailService]
})

export class FeedbackComponent implements OnInit {
  errorMessage:string;
  pageTitle: string = 'Course List';
  listFilter: string = '';
  courses: ICourse[];
  getData: string;
  constructor(private route:Router,private courseService: CourseService,private emailService:EmailService) { }

  ngOnInit():void {
    this.courseService.getCourse().subscribe(courses=>this.courses=courses, error=>this.errorMessage=<any>error);
  }

   
  onSubmit(id:number):any
  {
   console.log(id);
   this.emailService.sendEMAIL(id)
   .subscribe(
    data=>this.getData=JSON.stringify(data),
    error=>alert(error),
    ()=>console.log("Finished")
    )
   
  }

}


  

   
    

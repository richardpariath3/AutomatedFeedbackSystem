import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingfeedbackComponent } from './trainingfeedback.component';

describe('TrainingfeedbackComponent', () => {
  let component: TrainingfeedbackComponent;
  let fixture: ComponentFixture<TrainingfeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainingfeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

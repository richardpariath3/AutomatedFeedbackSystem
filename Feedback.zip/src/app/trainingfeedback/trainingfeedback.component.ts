import { Component, OnInit } from '@angular/core';
import {FeedbackformService} from '../services/feedbackform.service';
import {CourseService} from '../services/course.service';
import {Router} from '@angular/router';
import {FormsModule,FormGroup,FormBuilder } from '@angular/forms'
import {IFeedbackform} from '../feedbackform'
import {ICourse} from '../course'
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { CourseinFilterPipe} from '../course-in-filter.pipe'
import { CourseFilterPipe} from '../course-filter.pipe'
import { Observable } from 'rxjs/Observable';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import 'rxjs/add/observable/of';
import {ITest} from '../test';
import {TestService} from '../services/test.service';
import {KeysPipe} from '../keys.pipe'

@Component({
  selector: 'app-trainingfeedback',
  templateUrl: './trainingfeedback.component.html',
  styleUrls: ['./trainingfeedback.component.css'],
  providers:[FeedbackformService,TestService,CourseService]
})
export class TrainingfeedbackComponent implements OnInit {
errorMessage:string;
   feed:IFeedbackform[];
   courses:ICourse[];
   listFilter: string = '';
   listinFilter: string = '';
   getData:string;
   public myForm: FormGroup;
  constructor(private _sanitizer: DomSanitizer,private builder: FormBuilder,private feedbackService: FeedbackformService,private courseService: CourseService,private testService: TestService) { }

  ngOnInit():void {
    this.myForm=this.builder.group({
      feeds:"",
      
    })
    
   this.courseService.getCourse().subscribe((feed:ICourse[])=>this.courses=feed, error=>this.errorMessage=<any>error);
    
  
  // this.courseService.getCourse().subscribe((feede:ICourse[])=>this.feede=feede, error=>this.errorMessage=<any>error);
  }

autocompleListFormatter = (data: any) => {
    let html = `<span style='color:grey'>Title: ${data.title} | Instructor: ${data.instructor} | From: ${data.from_date} </span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }

  onSubmit(obj:number):void{
   this.feedbackService.getFeedbackform(obj).subscribe((feed:any)=>this.feed=feed, error=>this.errorMessage=<any>error);
  //  this.courses=this.testService.getCourse();
}

}




  

   
    

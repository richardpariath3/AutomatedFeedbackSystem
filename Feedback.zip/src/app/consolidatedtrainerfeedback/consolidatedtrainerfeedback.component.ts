import { Component, OnInit } from '@angular/core';
import {AmChartsService} from "@amcharts/amcharts3-angular";
import {CourseinFilterPipe} from '../course-in-filter.pipe';
import {FeedbackformService} from '../services/feedbackform.service';
import {IFeedbackform} from '../feedbackform'
import {ICourse} from '../course';
import {FormsModule ,FormGroup,FormBuilder} from '@angular/forms'
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import {CourseService} from '../services/course.service';
@Component({
  selector: 'app-consolidatedtrainerfeedback',
  templateUrl: './consolidatedtrainerfeedback.component.html',
  styleUrls: ['./consolidatedtrainerfeedback.component.css'],
  providers:[FeedbackformService,CourseService]
})
export class ConsolidatedtrainerfeedbackComponent implements OnInit {
private chart:any;
private indextab:number=-1;
listFilter: string = '';
feed:IFeedbackform[];
errorMessage:string;
courses:ICourse[];
listinFilter: string = '';
getData:string;
public myForm: FormGroup;
  constructor(private _sanitizer: DomSanitizer,private builder: FormBuilder,private courseService: CourseService,private AmCharts:AmChartsService,private feedbackService: FeedbackformService) { }

onSubmit(obj:number):void
{
 this.feedbackService.getFeedbackform(obj).subscribe((feed:IFeedbackform[])=>this.feed=feed, error=>this.errorMessage=<any>error);
 let countofcharts:number=5;
 let jsonValue:any;
 let i:number=1;
 jsonValue={ "1": [{"category": "Score NA","column-1": 0,},{"category": "Score 1","column-1": 2,},{"category": "Score 2","column-1": 7,},{"category": "Score 3","column-1": 10,},{"category": "Score 4","column-1": 18,},{"category": "Score 5","column-1": 52,},{"category": "Score 6","column-1": 40,},{"category": "Score 7","column-1": 30,},{"category": "Score 8","column-1": 82,},{"category": "Score 9","column-1": 12,},{"category": "Score 10","column-1": 21,}],
  "2": [{"category": "Score NA","column-1": 0,},{"category": "Score 1","column-1": 2,},{"category": "Score 2","column-1": 7,},{"category": "Score 3","column-1": 10,},{"category": "Score 4","column-1": 18,},{"category": "Score 5","column-1": 52,},{"category": "Score 6","column-1": 40,},{"category": "Score 7","column-1": 30,},{"category": "Score 8","column-1": 82,},{"category": "Score 9","column-1": 12,},{"category": "Score 10","column-1": 21,}],
 "3": [{"category": "Score NA","column-1": 0,},{"category": "Score 1","column-1": 2,},{"category": "Score 2","column-1": 7,},{"category": "Score 3","column-1": 10,},{"category": "Score 4","column-1": 18,},{"category": "Score 5","column-1": 52,},{"category": "Score 6","column-1": 40,},{"category": "Score 7","column-1": 30,},{"category": "Score 8","column-1": 82,},{"category": "Score 9","column-1": 12,},{"category": "Score 10","column-1": 21,}],
 "4": [{"category": "Score NA","column-1": 0,},{"category": "Score 1","column-1": 2,},{"category": "Score 2","column-1": 7,},{"category": "Score 3","column-1": 10,},{"category": "Score 4","column-1": 18,},{"category": "Score 5","column-1": 52,},{"category": "Score 6","column-1": 40,},{"category": "Score 7","column-1": 30,},{"category": "Score 8","column-1": 82,},{"category": "Score 9","column-1": 12,},{"category": "Score 10","column-1": 21,}],
 "5": [{"category": "Score NA","column-1": 0,},{"category": "Score 1","column-1": 2,},{"category": "Score 2","column-1": 7,},{"category": "Score 3","column-1": 10,},{"category": "Score 4","column-1": 18,},{"category": "Score 5","column-1": 52,},{"category": "Score 6","column-1": 40,},{"category": "Score 7","column-1": 30,},{"category": "Score 8","column-1": 82,},{"category": "Score 9","column-1": 12,},{"category": "Score 10","column-1": 21,}],

}


for(i=1;i<countofcharts;i++){
  this.chart=this.AmCharts.makeChart("chartdiv"+i,
    {
  "type": "pie",
  "theme": "none",
  "dataProvider": jsonValue[i],
  "titleField": "category",
  "valueField": "column-1",
  "labelRadius": 5,
  "radius": "20%",
  "legend":[
{
  "position":"right",
  "marginRight":100,
  "autoMargins":false
}
  ],
  "innerRadius": "60%",
  "labelText": "[[title]]-[[value]]"
    } 

    );
}
}
 

  ngOnInit() {
		   this.myForm=this.builder.group({
      feeds:"",
    })
     this.courseService.getCourse().subscribe((feed:ICourse[])=>this.courses=feed, error=>this.errorMessage=<any>error);
  //  this.courses=this.testService.getCourse();
		  
  }

	autocompleListFormatter = (data: any) => {
    let html = `<span style='color:grey'>Title: ${data.title} | Instructor: ${data.instructor} | From: ${data.from_date} </span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }


}




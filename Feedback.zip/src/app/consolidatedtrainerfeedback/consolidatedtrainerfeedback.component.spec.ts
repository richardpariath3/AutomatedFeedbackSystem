import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatedtrainerfeedbackComponent } from './consolidatedtrainerfeedback.component';

describe('ConsolidatedtrainerfeedbackComponent', () => {
  let component: ConsolidatedtrainerfeedbackComponent;
  let fixture: ComponentFixture<ConsolidatedtrainerfeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsolidatedtrainerfeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidatedtrainerfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

export interface ICourse
{
    cid:number;
    title:string;
    description:any;
    instructor_type:number;
    instructor:string;
    duration:number;
    total_cost:any;
    permanent_cost:any;
    no_of_participants:number;
    location:any;
    create_date:any;
    status:any;
    from_date:any;
    to_date:any;
   
   
}
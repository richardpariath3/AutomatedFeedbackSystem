import { Component } from '@angular/core';
import {Validators} from '@angular/forms';
import {Router,ActivatedRoute} from '@angular/router';
import {ReactiveFormsModule, FormGroup, FormControl} from '@angular/forms';
import {Http, Response, URLSearchParams, Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {ValuesService} from '../values.service';
import {ICourse} from '../course'


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  providers:[ValuesService]
})
export class FormComponent{
  
  randomnumber:any;
  errorMessage:string;
  private sub:any;
  getData:string=""
  constructor(private route:Router,private activatedRoute: ActivatedRoute, private valuesService:ValuesService)
  {

  }

  courses: ICourse[];

  ngOnInit():void{

  

    this.sub=this.activatedRoute.params.subscribe(params=>this.randomnumber=+params['randomnumber'])
    console.log(this.sub);
    //this.valuesService.getRND(this.sub);
    this.route.navigate(['form/',this.randomnumber])
    this.valuesService.getJSON().subscribe(courses=>this.courses=courses, error=>this.errorMessage=<any>error);

  }

  userForm = new FormGroup({
    Program_Rating: new FormControl(),
    Program_Objective: new FormControl(),
    Program_WorkEffectiveness:new FormControl(),
    Appropriateness: new FormControl(),
    Understandable:new FormControl(),
    Examples: new FormControl(),
    Excercise:new FormControl(),
    Duration: new FormControl(),
    Trainer_Knowledge:new FormControl(),
    Trainer_Delivery: new FormControl(),
    Trainer_Communication:new FormControl(),
    Trainer_Interactivity: new FormControl(),
    Trainer_Energy:new FormControl(),
    Comments: new FormControl(Validators.required),
 
  });


  onSubmit(value:any):any
  {
    if(this.userForm.valid)
    {
   console.log(value);
   this.valuesService.postJSON(value)
   .subscribe(
    data=>this.getData=JSON.stringify(data),
    error=>alert(error),
    ()=>console.log("Finished")
    )
  }
  else
  {
    alert("Please fill the comment section");
  }
}
onReset()
{
  this.userForm=new FormGroup(
    {
     Program_Rating: new FormControl(),
    Program_Objective: new FormControl(),
    Program_WorkEffectiveness:new FormControl(),
    Appropriateness: new FormControl(),
    Understandable:new FormControl(),
    Examples: new FormControl(),
    Excercise:new FormControl(),
    Duration: new FormControl(),
    Trainer_Knowledge:new FormControl(),
    Trainer_Delivery: new FormControl(),
    Trainer_Communication:new FormControl(),
    Trainer_Interactivity: new FormControl(),
    Trainer_Energy:new FormControl(),
    Comments: new FormControl(Validators.required),
 
    }
  )
}
}

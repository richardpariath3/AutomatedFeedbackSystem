import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {RouterModule, Routes, Router} from '@angular/router';
import {ActivatedRoute} from '@angular/router';
import { FormComponent } from './form/form.component';
import {ɵROUTER_PROVIDERS} from '@angular/router';
import {HttpModule} from '@angular/http';
import {} from '@angular/http';
export const appRoutes: Routes =[
  { path: 'form/:randomnumber',component:FormComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    FormComponent
  ],
  imports: [
    BrowserModule, HttpModule, ReactiveFormsModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  randomnumber:any;
  private sub:any;
  private url='http://192.168.22.23:7000/mail'
  constructor(private _route: ActivatedRoute, private route:Router,)
  {
     var param = route.parseUrl(url).queryParams["auth"];
    console.log("Extracted value: ")
    console.log(param);
  }

 }

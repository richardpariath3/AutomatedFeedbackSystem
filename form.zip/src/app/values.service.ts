import {AppComponent} from './app.component';
import {Injectable} from '@angular/core';
import {FormComponent} from './form/form.component';
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {ICourse} from './course';

@Injectable()
export class ValuesService
{
    randomnumber:any;
    constructor(protected http:Http){
    }
    
    headers=new Headers({
        'Content-Type':'application/json'
    });

   ngOnInit():void{
    
    
  }
  
    private urlstringcourse='http://192.168.22.23:7000/admin/display/courses';

    postJSON(value) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let body = JSON.stringify(value);
    return this.http.post('http://192.168.22.68:1199/form/randomnumber', body, options ).map((res: Response) => res.json());
  }




    getRND(value:any): any{
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
    let myParams = new URLSearchParams();
    myParams.append('cid',value);
    let body = myParams.toString();
    let options = new RequestOptions({ headers: headers });
    return this.http.get('http://192.168.22.23:7000/mail?cid='+value, options ).map((res: Response) => res.json());
  }
  
  
    

    getJSON(): Observable<ICourse[]>
    {
        return this.http.get(this.urlstringcourse).map((response:Response)=><ICourse[]>response.json())
        .do(data=>console.log('All: '+JSON.stringify(data)))
        .catch(this.handleError);
    }

    private handleError(error:Response)
    {
        console.error(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}